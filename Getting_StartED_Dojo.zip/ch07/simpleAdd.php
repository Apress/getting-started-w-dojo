<?php
  /*
   * produces {"simpleAdd":{"total":###}}
   */
  $total = array('total' => $_POST['firstNum'] + $_POST['secondNum']);
  $result = array('simpleAdd' => $total);
  echo json_encode($result);
?>