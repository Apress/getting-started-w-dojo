dojo.provide("com.hayes.form.TextBox");

dojo.require("dijit.form.TextBox");

dojo.declare("com.hayes.form.TextBox",
            [dijit.form.TextBox],
{
  placeholder: "",
  placeholderColor: "#999",
  textColor: "#000",
  
  /**
   * Ensure there is not already a value in the field
   * before setting the placeholder
   */
  setPlaceholder: function()
  {
    if(this.attr('displayedValue').length == 0)
    {
      this.attr('style', 'color:' + this.placeholderColor);
      this.attr('displayedValue', this.placeholder);
    }
  },
  
  /**
   * Upon the textbox gaining focus 
   */
  _onFocus: function()
  {
    this.unsetPlaceholder();
    this.inherited(arguments); // call super
    this.focus();
  },
  
  /**
   * Upon the textbox losing focus
   */
  _onBlur: function()
  {
    if(this.attr('displayedValue').length == 0)
    {
      this.setPlaceholder();
    }
    this.inherited(arguments); // call super
  },
  
  /**
   * Drops the placeholder text and returns the textbox
   * to normal
   */
  unsetPlaceholder: function()
  {
    this.attr('style', 'color:' + this.textColor);
    this.attr('displayedValue', '');
  },
  
  /**
   * Once this widget is created, determine if the placeholder
   * should be set
   */
  postCreate: function()
  {
    if(dojo.trim(this.placeholder).length > 0)
    {
      this.setPlaceholder();
    }
    this.inherited(arguments); // call super
  }
});