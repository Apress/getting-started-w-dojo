dojo.require('dojo.parser');
dojo.require("dojo.data.ItemFileReadStore");
dojo.require("dojo.fx");

dojo.require('dijit.form.Form');
dojo.require("dijit.layout.ContentPane");
dojo.require("dijit.layout.TabContainer");
dojo.require('dijit.form.TextBox');
dojo.require("dijit.form.ValidationTextBox");
dojo.require("dijit.form.NumberSpinner");
dojo.require("dijit.form.DateTextBox");
dojo.require("dijit.form.ComboBox");
dojo.require("dijit.ColorPalette");
dojo.require("dojox.validate.regexp");

var currentTab = 0;
var tabs = null;
var myForm = null;

var init = function(e)
{
	tabs = dijit.byId('tabs');
	myForm = dijit.byId('widgetsForm');
	
	dojo.connect(myForm, 'onblur', function(e){console.log(e);});
	
	dojo.connect(dojo.byId('nextButton1'),'onclick', nextButton_click);
	dojo.connect(dojo.byId('nextButton2'),'onclick', nextButton_click);
	dojo.connect(dojo.byId('prevButton2'),'onclick', prevButton_click);
	dojo.connect(dojo.byId('prevButton3'),'onclick', prevButton_click);
}

var nextButton_click = function(e)
{
	tabs.forward();
}

var prevButton_click = function(e)
{
	tabs.back();
}

dojo.addOnLoad(init);